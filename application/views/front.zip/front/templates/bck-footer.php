<br /><br />
<footer>
<div class="container">
	<div class="row">
		<div class="col-md-7 footer-col">
<i class="fa fa-phone-square fa-2x"></i> &nbsp;&nbsp;&nbsp; <span style="color:#000;">(+91) 971 170 4082 &nbsp;&nbsp; | &nbsp;&nbsp; (+91) 982 580 6005 </span>
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<i class="fa fa-envelope-square fa-2x"></i> &nbsp;&nbsp; <span style="color:#000;">  akhilesh@evolvelearningsolutions.com </span>
			</div>
	</div>
</div>
</footer>
<br />
<!-- Footer -->
<footer class="footer">
    <div class="container">
		<div class="row">
			<div class="col-md-9">
				<p class="copyright">&copy; Copyright 2015-16 Evolve Learning Solutions All Right Reserved Website Design By <a href="http://www.wabodryms.com/" target="_blank"> Wabodryms IT Solutions &TRADE; </a>.</p>
			</div>
			<div class="col-md-3 footer-col">
				<a href="https://www.facebook.com/evolvelearningsolutions" class="fa fa-fw fa-facebook" target="_blank"></a>
				<a href="https://twitter.com/akhilesh_evolve" class="fa fa-fw fa-twitter" target="_blank"></a>
				<a href="https://www.linkedin.com/company/evolve-learning-solutions" class="fa fa-fw fa-linkedin" target="_blank"></a>
				<a href="https://www.youtube.com/channel/UClD90ct4DaxOKGHttZfKU-Q" class="fa fa-fw fa-youtube"  target="_blank"></a>
			</div>
		</div>
	</div>
</footer>
<!-- /Footer -->

<!-- Scroll To Top -->
<div id="scroll-to-top" class="scroll-to-top">
    <i class="icon fa fa-angle-up"></i>
</div>
<!-- /Scroll To Top -->

<!-- SCRIPTS -->
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
<script src="<?php echo base_url(); ?>js/jquery-2.2.0.min.js"></script>
<script src="<?php echo base_url(); ?>js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>js/owl.carousel.min.js"></script>
<script src="<?php echo base_url(); ?>js/jquery.magnific-popup.min.js"></script>
<script src="<?php echo base_url(); ?>js/jquery.validate.min.js"></script>
<script src="<?php echo base_url(); ?>js/jquery.stellar.min.js"></script>
<script src="<?php echo base_url(); ?>js/wow.min.js"></script>
<script src="<?php echo base_url(); ?>js/masonry.pkgd.min.js"></script>
<script src="<?php echo base_url(); ?>js/jquery.appear.js"></script>
<script src="<?php echo base_url(); ?>js/jquery.animateNumber.min.js"></script>
<script src="<?php echo base_url(); ?>js/general.js"></script>
<script src="http://localhost/evolve/dist/jquery.mousewheel.min.js"></script>
<!-- /SCRIPTS -->


</body>

</html>